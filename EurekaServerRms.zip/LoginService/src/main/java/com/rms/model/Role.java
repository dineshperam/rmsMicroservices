package com.rms.model;

public enum Role {
	ARTIST,ADMIN,MANAGER

}
