package com.rms.exeptions;

public class InvalidStreamException extends RuntimeException {
    
    public InvalidStreamException(String message) {
        super(message);
    }
}
