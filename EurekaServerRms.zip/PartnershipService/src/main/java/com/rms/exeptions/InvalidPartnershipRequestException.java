package com.rms.exeptions;

public class InvalidPartnershipRequestException extends RuntimeException {

    public InvalidPartnershipRequestException(String message) {
        super(message);
    }

}
