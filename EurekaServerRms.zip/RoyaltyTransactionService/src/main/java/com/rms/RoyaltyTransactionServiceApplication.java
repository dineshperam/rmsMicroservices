package com.rms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoyaltyTransactionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoyaltyTransactionServiceApplication.class, args);
	}

}
